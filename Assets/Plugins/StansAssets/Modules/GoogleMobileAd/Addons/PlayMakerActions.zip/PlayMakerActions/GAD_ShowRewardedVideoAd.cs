﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Google Mobile Ad")]
	[Tooltip("Show Rewarded Video Ad (ANDROID PLATFORM ONLY)")]
	public class GAD_ShowRewardedVideoAd : FsmStateAction {
		[Tooltip("Called when a rewarded video ad opens a overlay that covers the screen.")]
		public FsmEvent adOpenedEvent;

		[Tooltip("Called when a rewarded video ad starts to play.")]
		public FsmEvent startedEvent;

		[Tooltip("Called when a rewarded video ad leaves the application (e.g., to go to the browser).")]
		public FsmEvent adLeftApplication;

		[Tooltip("Called when a rewarded video ad has triggered a reward. The app is responsible for crediting the user with the reward.")]
		public FsmEvent rewardedEvent;
		
		[Tooltip("Called when a rewarded video ad is closed.")]
		public FsmEvent adClosedEvent;
		
		public FsmString item;
		public FsmInt amount;
		
		public override void OnEnter() {
#if UNITY_ANDROID
			AndroidAdMobController.Instance.OnRewardedVideoAdClosed += OnReady;
			AndroidAdMobController.Instance.OnRewarded += Rewarded;
			AndroidAdMobController.Instance.OnRewardedVideoAdOpened += RewardedVideoAdOpened;
			AndroidAdMobController.Instance.OnRewardedVideoStarted += RewardedVideoStarted;
			AndroidAdMobController.Instance.OnRewardedVideoAdLeftApplication += RewardedVideoAdLeftApplication;
			AndroidAdMobController.Instance.ShowRewardedVideo();
#endif
			item.Value = "item";
			amount.Value = 0;
			
#if UNITY_EDITOR
			OnReady();
#endif
		}

		private void OnReady() {
#if UNITY_ANDROID
			AndroidAdMobController.Instance.OnRewardedVideoAdClosed -= OnReady;
			AndroidAdMobController.Instance.OnRewarded -= Rewarded;
			AndroidAdMobController.Instance.OnRewardedVideoAdOpened -= RewardedVideoAdOpened;
			AndroidAdMobController.Instance.OnRewardedVideoStarted -= RewardedVideoStarted;
			AndroidAdMobController.Instance.OnRewardedVideoAdLeftApplication -= RewardedVideoAdLeftApplication;
#endif
			Fsm.Event(adClosedEvent);
			Finish();
		}

		private void Rewarded(string i, int a) {
			item.Value = i;
			amount.Value = a;

			Fsm.Event(rewardedEvent);
		}

		private void RewardedVideoAdOpened() {
			Fsm.Event(adOpenedEvent);
		}

		private void RewardedVideoStarted() {
			Fsm.Event(startedEvent);
		}

		private void RewardedVideoAdLeftApplication() {
			Fsm.Event(adLeftApplication);
		}
	}
}
